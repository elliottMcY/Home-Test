document.addEventListener('DOMContentLoaded', () => {
    let url = "https://people.canonical.com/~anthonydillon/wp-json/wp/v2/posts.json";


    fetch(url)
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            let postsContainer = document.getElementById('blog-posts');
            
            let cardsHTML = '';

            data.forEach(post => {

                const formattedDate = post.date.replace('T', ' ');

                cardsHTML += `
                    <div class="col-4">
                        <div class="p-card u-no-padding">
                            <h5 class="top_title">CLOUD AND SERVER</h5>
                            <div class="dashline_top_img"></div>
                            <img class="p-card__image" src="${post.featured_media}" alt="Image for ${post.title.rendered}" class="p-card__thumbnail">
                            <div class="p-card__inner">
                                <h3 class="main_title">${post.title.rendered}</h3>
                            </div>
                            
                            <div class="p-card__inner">
                                <h5>By <a href="${post.link}">${post.id}</a> on ${formattedDate}</h5>
                            </div>
                            <div class="dashline_bottom_title"></div>
                            <p class="bottom_article">Article</p>
                        </div>
                    </div>
                `;
            });

            postsContainer.innerHTML = `<div class="row">${cardsHTML}</div>`;
        })
        .catch(error => {
            console.log('There was a problem with the fetch operation:', error.message);
        });
});
