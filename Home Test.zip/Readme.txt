Dear recruiter,

After unzipping the file, please open the index.html file directly, and the result page will be shown.

Thank you for reviewing my code!